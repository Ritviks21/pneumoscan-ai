# PneumoScan AI — Sample X-ray Images

This archive contains example chest X-ray images for trying the PneumoScan AI research prototype.

## Contents
- `Normal/` — images labelled Normal in the supplied answer key.
- `Pneumonia/` — images labelled Pneumonia in the supplied answer key.
- `sample_labels.csv` — filenames and their supplied reference labels.

## How to try an image
1. Extract this ZIP file.
2. Open the PneumoScan AI Streamlit demo.
3. Select a model (Baseline CNN, MobileNetV2 - Frozen, or MobileNetV2 - Fine-tuned).
4. Upload one PNG image from either folder and select Analyze X-ray.

Live demo: https://pneumoscan-ai-tnglamtsnsg4yd37q84jyw.streamlit.app/

## Important
These are dataset examples for educational demonstration only. The folder names and CSV labels are reference dataset labels, not a new clinical assessment. Model outputs may be incorrect. This project is an academic research prototype, not a medical device; do not use it for diagnosis or treatment.

Before redistributing these images publicly, ensure your use complies with the source dataset's license and attribution requirements.
